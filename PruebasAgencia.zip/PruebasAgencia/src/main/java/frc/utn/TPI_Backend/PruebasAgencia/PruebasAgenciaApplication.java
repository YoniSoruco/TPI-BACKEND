package frc.utn.TPI_Backend.PruebasAgencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebasAgenciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebasAgenciaApplication.class, args);
	}

}
