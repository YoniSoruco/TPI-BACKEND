package frc.utn.TPI_Backend.PruebasAgencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebasAgenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
